"""
GRO120: Module filtrage - implémentation des filtres à appliquer sur les données lidar 

Auteurs: Simon Lacroix et Vincent Duchesne
Date: 07/10/2026
"""

from analyse import insertion_sort


#===========================================
def filtre_min_max(points, distance_min=0.5, distance_max=15.0):
    """
    DESC: Filtre les points en éliminant ceux qui sont hors des bornes min/max.
          Les valeurs inférieures à la borne min sont remplacées par -1.
          Les valeurs supérieures à la borne max sont remplacées par max.
          
    RETOUR: Tableau de données filtrées
    """

    # créer un tableau vide afin d'y mettre la solution
    points_filtre = []

    # créer une boucle for afin de parcourir le tableau
    for i in range(len(points)):
        # remplacer la valeur par le minimum si elle est sous celui-ci
        if (points[i] < distance_min):
            points_filtre.append(-1)
        # remplacer la valeur par le maximum si elle est au-dessus de celui-ci
        elif (points[i] > distance_max):
            points_filtre.append(distance_max)
        # garder la valeur telle quelle
        else:
            points_filtre.append(points[i])

    # Retourner la nouvelle liste filtrée
    return points_filtre


def filtre_moyenne_mobile(points):
    """
    DESC: Filtre les points en remplaçant chaque point par une moyenne mobile.
          La moyenne est calculée avec une fenêtre de 3 points (le point lui-même et ceux avant et après).
          Pour les valeurs aux extrémités, seulement une fenêtre de 2 points est utilisée.
          
    RETOUR: Tableau de données filtrées
    """
    # nouvelle liste de points pour éviter de modifier l'originale
    points_filtres = []

    # itérer à travers les points
    for index in range(len(points)):
        # garder en mémoire le nombre d'éléments à moyenner et leur somme
        # initialiser avec l'élément à l'index actuel
        somme = points[index]
        nbElements = 1
        # si ce n'est pas le premier élément, rajouter l'élément précédent
        if (index > 0):
            somme += points[index - 1]
            nbElements += 1
        # si ce n'est pas le dernier élément, rajouter l'élément suivant
        if (index < (len(points) - 1)):
            somme += points[index + 1]
            nbElements += 1

        # faire la moyenne des éléments
        moyenne = somme / nbElements
        # ajouter le nouveau point calculé à une décimale
        points_filtres.append(round(moyenne, 1))

    # retourner le tableau de données filtrées
    return points_filtres


def filtre_mediane_mobile(points):
    """
    DESC: Filtre les points en remplaçant chaque point par une médiane mobile.
          La médiane est calculée avec une fenêtre de 3 points (le point lui-même et ceux avant et après).
          Pour les valeurs aux extrémités, le point original est conservé.
          
    RETOUR: Tableau de données filtrées
    """
    # nouvelle liste de points pour éviter de modifier l'originale
    points_filtres = []

    # itérer à travers les points
    for index in range(len(points)):
        # si c'est le premier ou dernier élément, garder le même point
        if ((index == 0) or (index == len(points) - 1)):
            points_filtres.append(points[index])
        else:
            # sinon, créer une liste avec le point et ses deux voisins
            points_mediane = [
                points[index - 1], points[index], points[index + 1]
            ]

            # mettre en ordre cette liste
            points_mediane = insertion_sort(points_mediane)

            # prendre la 2e valeur sur 3 (celle au milieu)
            points_filtres.append(points_mediane[1])

    # retourner le tableau de données filtrées
    return points_filtres
