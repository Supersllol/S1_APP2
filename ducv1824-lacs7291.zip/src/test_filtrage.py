"""
GRO120: Tests unitaires pour le module filtrage

Auteur: Francois Ferland
Date: 18/09/2025

Modifié par: Simon Lacroix et Vincent Duchesne
Date: 07/10/2026
"""

import filtrage


#===========================================
def test_filtre_min_max():
    """
    DESC: Teste la fonction filtre_min_max
     
    """
    donnees = [1, 50, 0]
    reponse = [1, 10, -1]
    test = filtrage.filtre_min_max(donnees, 1, 10)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test liste vide
    donnees = []
    reponse = []
    test = filtrage.filtre_min_max(donnees, 1, 10)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test une donnée
    donnees = [0]
    reponse = [-1]
    test = filtrage.filtre_min_max(donnees, 1, 10)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test donnée négative et chiffre à virgule
    donnees = [-234.234, 123456.4, 10]
    reponse = [-1, 10, 10]
    test = filtrage.filtre_min_max(donnees, 1, 10)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    donnees = [-1, -50, 0]
    reponse = [-1, -1, 0]
    test = filtrage.filtre_min_max(donnees, 0, 10)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    donnees = [1, -1, -10, 0, 19]
    reponse = [1, -1, -1, -1, 1]
    test = filtrage.filtre_min_max(donnees, 1, 1)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    donnees = [-1, 50, 0, 5]
    reponse = [-1, 10.6, -1, 5]
    test = filtrage.filtre_min_max(donnees, 1.2, 10.6)
    assert test == reponse, f"Erreur: {test} != {reponse}"


def tests_filtre_moyenne_mobile():
    """
        DESC: Teste la fonction filtre_moyenne_mobile
        
    """
    # test liste vide
    donnees = []
    reponse = []
    test = filtrage.filtre_moyenne_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test une valeur
    donnees = [0]
    reponse = [0]
    test = filtrage.filtre_moyenne_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test liste à deux éléments
    donnees = [3, 3]
    reponse = [3, 3]
    test = filtrage.filtre_moyenne_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test liste à plus de 2 éléments
    donnees = [1.2, 1.6, 45.6]
    reponse = [1.4, 16.1, 23.6]
    test = filtrage.filtre_moyenne_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    donnees = [1, 3, 2, 4, 5, 3]
    reponse = [2.0, 2.0, 3.0, 3.7, 4.0, 4.0]
    test = filtrage.filtre_moyenne_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test valeur négative
    donnees = [-1]
    reponse = [-1]
    test = filtrage.filtre_moyenne_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    donnees = [-1, 2, 7, 0]
    reponse = [0.5, 2.7, 3, 3.5]
    test = filtrage.filtre_moyenne_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"


def tests_filtre_mediane_mobile():
    """
        DESC: Teste la fonction filtre_mediane_mobile
            
    """
    # test liste vide
    donnees = []
    reponse = []
    test = filtrage.filtre_mediane_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test liste à un élément
    donnees = [0]
    reponse = [0]
    test = filtrage.filtre_mediane_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test à plusieurs éléments
    donnees = [1, 2, 3, 4, 5]
    reponse = [1, 2, 3, 4, 5]
    test = filtrage.filtre_mediane_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test à valeurs variées
    donnees = [-1, 0, 9.5, 5.6, 7, 4, -1]
    reponse = [-1, 0, 5.6, 7, 5.6, 4, -1]
    test = filtrage.filtre_mediane_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    donnees = [-1, 2, 7, 0]
    reponse = [-1, 2, 2, 0]
    test = filtrage.filtre_mediane_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"

    # test avec valeurs identiques
    donnees = [0, 1, 1, 0]
    reponse = [0, 1, 1, 0]
    test = filtrage.filtre_mediane_mobile(donnees)
    assert test == reponse, f"Erreur: {test} != {reponse}"


#===========================================
if __name__ == "__main__":
    """
    DESC: Point d'entrée du programme
    """
    # appeler toutes les fonctions de tests
    test_filtre_min_max()
    tests_filtre_moyenne_mobile()
    tests_filtre_mediane_mobile()

    # si le programme s'est rendu jusqu'ici, aucun test n'a échoué
    print("Tous les tests ont réussi.")
